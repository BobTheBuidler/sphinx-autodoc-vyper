"""Vyper Sphinx documentation generator."""

__version__ = "0.1.0"